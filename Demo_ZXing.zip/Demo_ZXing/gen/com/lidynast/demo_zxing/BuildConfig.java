/** Automatically generated file. DO NOT MODIFY */
package com.lidynast.demo_zxing;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}